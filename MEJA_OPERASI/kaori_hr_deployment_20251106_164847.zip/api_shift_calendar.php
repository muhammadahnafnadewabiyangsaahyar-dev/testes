<?php
// Strict error handling for JSON API
error_reporting(0);
ini_set('display_errors', 0);

// Start output buffering immediately
ob_start();

session_start();
require_once 'connect.php';

// Clear any previous output
ob_end_clean();

// Start fresh output buffer
ob_start();

// Set JSON header
header('Content-Type: application/json; charset=utf-8');

// Disable any potential output from error handlers
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error [$errno]: $errstr in $errfile on line $errline");
    return true;
});

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$admin_id = $_SESSION['user_id'];

// Get action from request
$action = $_GET['action'] ?? $_POST['action'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if ($input) {
        $action = $input['action'] ?? $action;
    }
}

try {
    switch ($action) {
        case 'get_cabang':
            getCabang();
            break;
            
        case 'get_shifts':
            getShifts();
            break;
            
        case 'get_pegawai':
            getPegawai();
            break;
            
        case 'get_assignments':
            getAssignments();
            break;
            
        case 'create':
            createAssignment();
            break;
            
        case 'assign_shifts':
            assignShiftsBatch();
            break;
            
        case 'update':
            updateAssignment();
            break;
            
        case 'delete':
            deleteAssignment();
            break;
            
        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

// Get all cabang (unique outlets from cabang_outlet)
function getCabang() {
    global $pdo;
    
    $sql = "SELECT id, nama_cabang 
            FROM cabang_outlet 
            ORDER BY nama_cabang";
    
    $stmt = $pdo->query($sql);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['status' => 'success', 'data' => $data]);
}

// Get shifts for specific outlet
function getShifts() {
    global $pdo;
    
    $outlet_name = $_GET['outlet'] ?? null;
    
    if (!$outlet_name) {
        echo json_encode(['status' => 'error', 'message' => 'Outlet harus dipilih']);
        return;
    }
    
    $sql = "SELECT id, nama_cabang, nama_shift, jam_masuk, jam_keluar 
            FROM cabang 
            WHERE nama_cabang = :outlet
            ORDER BY 
                CASE nama_shift
                    WHEN 'pagi' THEN 1
                    WHEN 'middle' THEN 2
                    WHEN 'sore' THEN 3
                    ELSE 4
                END";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['outlet' => $outlet_name]);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['status' => 'success', 'data' => $data]);
}

// Get pegawai (users for specific outlet)
function getPegawai() {
    global $pdo;
    
    $outlet_name = $_GET['outlet'] ?? null;
    
    if (!$outlet_name) {
        echo json_encode(['status' => 'error', 'message' => 'Outlet harus dipilih']);
        return;
    }
    
    $sql = "SELECT id, nama_lengkap as name, posisi, outlet 
            FROM register 
            WHERE role = 'user' AND outlet = :outlet
            ORDER BY nama_lengkap";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['outlet' => $outlet_name]);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['status' => 'success', 'data' => $data]);
}

// Get shift assignments
function getAssignments() {
    global $pdo;
    
    $month = $_GET['month'] ?? date('Y-m');
    $cabang_id = $_GET['cabang_id'] ?? null;
    
    // Parse month to get start and end dates
    $startDate = $month . '-01';
    $endDate = date('Y-m-t', strtotime($startDate));
    
    $sql = "SELECT 
                sa.id,
                sa.user_id,
                sa.cabang_id,
                sa.tanggal_shift,
                sa.status_konfirmasi,
                DATE_FORMAT(CONCAT(sa.tanggal_shift, ' ', c.jam_masuk), '%Y-%m-%d %H:%i:%s') as start,
                DATE_FORMAT(CONCAT(sa.tanggal_shift, ' ', c.jam_keluar), '%Y-%m-%d %H:%i:%s') as end,
                c.nama_cabang,
                c.nama_shift,
                c.jam_masuk,
                c.jam_keluar,
                r.nama_lengkap
            FROM shift_assignments sa
            JOIN cabang c ON sa.cabang_id = c.id
            JOIN register r ON sa.user_id = r.id
            WHERE sa.tanggal_shift BETWEEN :start_date AND :end_date";
    
    // Filter by outlet name (nama_cabang) instead of specific cabang_id
    // This ensures all shift types for an outlet are included
    if ($cabang_id) {
        // Get the outlet name for this cabang_id
        $sql .= " AND c.nama_cabang = (SELECT nama_cabang FROM cabang WHERE id = :cabang_id LIMIT 1)";
    }
    
    $sql .= " ORDER BY sa.tanggal_shift, sa.user_id";
    
    $stmt = $pdo->prepare($sql);
    
    $params = [
        'start_date' => $startDate,
        'end_date' => $endDate
    ];
    
    if ($cabang_id) {
        $params['cabang_id'] = $cabang_id;
    }
    
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['status' => 'success', 'data' => $data]);
}

// Create new assignment
function createAssignment() {
    global $pdo, $admin_id;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $user_id = $input['user_id'] ?? null;
    $cabang_id = $input['cabang_id'] ?? null;
    $tanggal_shift = $input['tanggal_shift'] ?? null;
    
    if (!$user_id || !$cabang_id || !$tanggal_shift) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
        return;
    }
    
    // Check if assignment already exists
    $sql_check = "SELECT id FROM shift_assignments 
                  WHERE user_id = ? AND tanggal_shift = ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$user_id, $tanggal_shift]);
    
    if ($stmt_check->rowCount() > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Pegawai sudah memiliki shift pada tanggal ini']);
        return;
    }
    
    // Insert new assignment
    $sql = "INSERT INTO shift_assignments 
            (user_id, cabang_id, tanggal_shift, created_by, created_at) 
            VALUES (?, ?, ?, ?, NOW())";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $cabang_id, $tanggal_shift, $admin_id]);
    
    $id = $pdo->lastInsertId();
    
    // Get cabang info with shift time
    $sql_cabang = "SELECT nama_cabang, nama_shift, jam_masuk, jam_keluar FROM cabang WHERE id = ?";
    $stmt_cabang = $pdo->prepare($sql_cabang);
    $stmt_cabang->execute([$cabang_id]);
    $cabang = $stmt_cabang->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Shift berhasil di-assign',
        'data' => [
            'id' => $id,
            'nama_cabang' => $cabang['nama_cabang'],
            'nama_shift' => $cabang['nama_shift'],
            'jam_masuk' => $cabang['jam_masuk'],
            'jam_keluar' => $cabang['jam_keluar']
        ]
    ]);
}

// Assign shifts in batch
function assignShiftsBatch() {
    global $pdo, $admin_id;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $assignments = $input['assignments'] ?? null;
    
    if (!$assignments || !is_array($assignments)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
        return;
    }
    
    foreach ($assignments as $assignment) {
        $user_id = $assignment['user_id'] ?? null;
        $cabang_id = $assignment['cabang_id'] ?? null;
        $tanggal_shift = $assignment['tanggal_shift'] ?? null;
        
        if (!$user_id || !$cabang_id || !$tanggal_shift) {
            echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
            return;
        }
        
        // Check if assignment already exists
        $sql_check = "SELECT id FROM shift_assignments 
                      WHERE user_id = ? AND tanggal_shift = ?";
        $stmt_check = $pdo->prepare($sql_check);
        $stmt_check->execute([$user_id, $tanggal_shift]);
        
        if ($stmt_check->rowCount() > 0) {
            continue; // Skip to next assignment if already exists
        }
        
        // Insert new assignment
        $sql = "INSERT INTO shift_assignments 
                (user_id, cabang_id, tanggal_shift, created_by, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user_id, $cabang_id, $tanggal_shift, $admin_id]);
    }
    
    echo json_encode(['status' => 'success', 'message' => 'Shift berhasil di-assign']);
}

// Update assignment
function updateAssignment() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $id = $input['id'] ?? null;
    $user_id = $input['user_id'] ?? null;
    $tanggal_shift = $input['tanggal_shift'] ?? null;
    
    if (!$id || !$user_id || !$tanggal_shift) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
        return;
    }
    
    // Check if assignment is approved - if so, prevent update
    $sql_status = "SELECT status_konfirmasi FROM shift_assignments WHERE id = ?";
    $stmt_status = $pdo->prepare($sql_status);
    $stmt_status->execute([$id]);
    $status_data = $stmt_status->fetch(PDO::FETCH_ASSOC);
    
    if ($status_data && $status_data['status_konfirmasi'] === 'approved') {
        echo json_encode(['status' => 'error', 'message' => 'Shift yang sudah approved tidak dapat diubah']);
        return;
    }
    
    // Check if new user already has assignment on that date
    $sql_check = "SELECT id FROM shift_assignments 
                  WHERE user_id = ? AND tanggal_shift = ? AND id != ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$user_id, $tanggal_shift, $id]);
    
    if ($stmt_check->rowCount() > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Pegawai sudah memiliki shift pada tanggal ini']);
        return;
    }
    
    // Update assignment
    $sql = "UPDATE shift_assignments 
            SET user_id = ?, tanggal_shift = ?, status_konfirmasi = 'pending', updated_at = NOW()
            WHERE id = ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $tanggal_shift, $id]);
    
    echo json_encode(['status' => 'success', 'message' => 'Shift berhasil diupdate']);
}

// Delete assignment
function deleteAssignment() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $id = $input['id'] ?? null;
    
    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'ID tidak valid']);
        return;
    }
    
    // Check if assignment is approved - if so, prevent deletion
    $sql_status = "SELECT status_konfirmasi FROM shift_assignments WHERE id = ?";
    $stmt_status = $pdo->prepare($sql_status);
    $stmt_status->execute([$id]);
    $status_data = $stmt_status->fetch(PDO::FETCH_ASSOC);
    
    if ($status_data && $status_data['status_konfirmasi'] === 'approved') {
        echo json_encode(['status' => 'error', 'message' => 'Shift yang sudah approved tidak dapat dihapus']);
        return;
    }
    
    $sql = "DELETE FROM shift_assignments WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    
    echo json_encode(['status' => 'success', 'message' => 'Shift berhasil dihapus']);
}
?>
